'use strict';

(function registerOnePunch(global) {
  const suite = global.__gameAssistantSuite
  if (!suite) return

  suite.registerEvalTransform('one-punch', function (code) {
    if (!suite.isEnabled('onePunch') || !code.includes('f.neoMaxCount') || !code.includes('tf.da = () =>')) {
      return code
    }
    return code.replace(/f\.neoCount\s*-=\s*[^;|\n]+/, 'f.neoCount = 0;')
  })
})(window)
