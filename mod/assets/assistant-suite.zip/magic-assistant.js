'use strict';

(function registerMagicAssistant(global) {
  const suite = global.__gameAssistantSuite
  if (!suite) return

  suite.registerEvalTransform('magic-assistant', function (code) {
    if (!suite.isEnabled('magicAssistant') || !code.includes('tf.osePhase') || !code.includes('Math.floor') || !code.includes('f.judge')) {
      return code
    }
    let processed = code.replace(/f\.judge\s*=\s*['"][^'"]+['"]/g, "f.judge = 'perfect'")
    if (processed.trim().endsWith('}')) processed += "\nf.judge = 'perfect';"
    return processed
  })
})(window)
